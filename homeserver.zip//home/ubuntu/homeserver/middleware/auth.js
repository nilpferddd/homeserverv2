// Middleware für Authentifizierungsprüfung
const ensureAuthenticated = (req, res, next) => {
  if (req.isAuthenticated()) {
    return next();
  }
  req.flash('error_msg', 'Bitte melden Sie sich an, um diese Seite zu sehen');
  res.redirect('/auth/login');
};

// Middleware für Admin-Berechtigungsprüfung
const ensureAdmin = (req, res, next) => {
  if (req.isAuthenticated() && req.user.isAdmin) {
    return next();
  }
  req.flash('error_msg', 'Sie benötigen Administratorrechte für diese Seite');
  res.redirect('/dashboard');
};

module.exports = { ensureAuthenticated, ensureAdmin };
